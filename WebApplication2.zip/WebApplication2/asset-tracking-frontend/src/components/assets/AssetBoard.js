import { useEffect, useState } from "react";
import { useDispatch, useSelector } from "react-redux";
import { DragDropContext, Draggable, Droppable } from "react-beautiful-dnd";
import {
  Box,
  Card,
  CardContent,
  Typography,
  Grid,
  Paper,
  IconButton,
  Tooltip,
  CircularProgress,
} from "@mui/material";
import { Edit as EditIcon, Delete as DeleteIcon } from "@mui/icons-material";
import { fetchAssets, updateAsset, deleteAsset } from "../../store/assetSlice";

const AssetBoard = () => {
  const dispatch = useDispatch();
  const {
    items: assets,
    loading,
    error,
  } = useSelector((state) => state.assets);
  const [zones, setZones] = useState([
    { id: "zone1", title: "Zone 1" },
    { id: "zone2", title: "Zone 2" },
    { id: "zone3", title: "Zone 3" },
  ]);

  useEffect(() => {
    dispatch(fetchAssets());
  }, [dispatch]);

  const handleDragEnd = (result) => {
    const { destination, source, draggableId } = result;

    if (!destination) return;

    if (
      destination.droppableId === source.droppableId &&
      destination.index === source.index
    ) {
      return;
    }

    const asset = assets.find((a) => a.assetId.toString() === draggableId);
    if (asset) {
      dispatch(
        updateAsset({
          id: asset.assetId,
          zoneId: parseInt(destination.droppableId),
        })
      );
    }
  };

  const handleDeleteAsset = (assetId) => {
    if (window.confirm("Are you sure you want to delete this asset?")) {
      dispatch(deleteAsset(assetId));
    }
  };

  if (loading) {
    return (
      <Box
        display="flex"
        justifyContent="center"
        alignItems="center"
        minHeight="200px"
      >
        <CircularProgress />
      </Box>
    );
  }

  if (error) {
    return (
      <Box
        display="flex"
        justifyContent="center"
        alignItems="center"
        minHeight="200px"
      >
        <Typography color="error">{error}</Typography>
      </Box>
    );
  }

  return (
    <DragDropContext onDragEnd={handleDragEnd}>
      <Box sx={{ flexGrow: 1, p: 3 }}>
        <Grid container spacing={3}>
          {zones.map((zone) => (
            <Grid item xs={12} md={4} key={zone.id}>
              <Paper
                sx={{
                  p: 2,
                  minHeight: 500,
                  backgroundColor: "#f5f5f5",
                }}
              >
                <Typography variant="h6" gutterBottom>
                  {zone.title}
                </Typography>
                <Droppable droppableId={zone.id}>
                  {(provided) => (
                    <Box
                      ref={provided.innerRef}
                      {...provided.droppableProps}
                      sx={{ minHeight: "100%" }}
                    >
                      {assets
                        .filter((asset) => asset.zoneId.toString() === zone.id)
                        .map((asset, index) => (
                          <Draggable
                            key={asset.assetId}
                            draggableId={asset.assetId.toString()}
                            index={index}
                          >
                            {(provided) => (
                              <Card
                                ref={provided.innerRef}
                                {...provided.draggableProps}
                                {...provided.dragHandleProps}
                                sx={{ mb: 2 }}
                              >
                                <CardContent>
                                  <Typography variant="h6">
                                    {asset.assetName}
                                  </Typography>
                                  <Typography color="textSecondary">
                                    {asset.description}
                                  </Typography>
                                  <Box
                                    sx={{
                                      mt: 1,
                                      display: "flex",
                                      justifyContent: "flex-end",
                                    }}
                                  >
                                    <Tooltip title="Edit">
                                      <IconButton size="small">
                                        <EditIcon />
                                      </IconButton>
                                    </Tooltip>
                                    <Tooltip title="Delete">
                                      <IconButton
                                        size="small"
                                        onClick={() =>
                                          handleDeleteAsset(asset.assetId)
                                        }
                                      >
                                        <DeleteIcon />
                                      </IconButton>
                                    </Tooltip>
                                  </Box>
                                </CardContent>
                              </Card>
                            )}
                          </Draggable>
                        ))}
                      {provided.placeholder}
                    </Box>
                  )}
                </Droppable>
              </Paper>
            </Grid>
          ))}
        </Grid>
      </Box>
    </DragDropContext>
  );
};

export default AssetBoard;
