import React, { useEffect, useState } from "react";
import { DragDropContext, Droppable, Draggable } from "react-beautiful-dnd";
import {
  Paper,
  Typography,
  Card,
  CardContent,
  Grid,
  Box,
  Chip,
  IconButton,
  Tooltip,
} from "@mui/material";
import { Edit as EditIcon, Delete as DeleteIcon } from "@mui/icons-material";
import { useDispatch, useSelector } from "react-redux";
import { fetchAssets } from "../../store/assetSlice";
import { fetchZones } from "../../store/zoneSlice";

const AssetKanban = () => {
  const dispatch = useDispatch();
  const assets = useSelector((state) => state.assets.items);
  const zones = useSelector((state) => state.zones.items);
  const [organizedAssets, setOrganizedAssets] = useState({});

  useEffect(() => {
    dispatch(fetchAssets());
    dispatch(fetchZones());
  }, [dispatch]);

  useEffect(() => {
    // Organize assets by zone
    const assetsByZone = {};
    zones.forEach((zone) => {
      assetsByZone[zone.zoneId] = assets.filter(
        (asset) => asset.zoneId === zone.zoneId
      );
    });
    setOrganizedAssets(assetsByZone);
  }, [assets, zones]);

  const handleDragEnd = (result) => {
    const { destination, source, draggableId } = result;

    if (!destination) return;

    if (
      destination.droppableId === source.droppableId &&
      destination.index === source.index
    ) {
      return;
    }

    // Here you would implement the logic to update the asset's zone in the backend
    const assetId = parseInt(draggableId);
    const newZoneId = parseInt(destination.droppableId);

    // Update asset zone in backend
    // dispatch(updateAssetZone({ assetId, newZoneId }));
  };

  const getCardColor = (type) => {
    switch (type?.toLowerCase()) {
      case "electronics":
        return "#e3f2fd"; // Light blue
      case "infrastructure":
        return "#f3e5f5"; // Light purple
      case "furniture":
        return "#e8f5e9"; // Light green
      default:
        return "#ffffff"; // White
    }
  };

  return (
    <DragDropContext onDragEnd={handleDragEnd}>
      <Box sx={{ display: "flex", gap: 2, overflow: "auto", p: 2 }}>
        {zones.map((zone) => (
          <Paper
            key={zone.zoneId}
            sx={{
              minWidth: 300,
              maxWidth: 300,
              bgcolor: "#f5f5f5",
              p: 2,
              borderRadius: 2,
            }}
          >
            <Typography variant="h6" gutterBottom sx={{ mb: 2 }}>
              {zone.zoneName}
            </Typography>
            <Droppable droppableId={zone.zoneId.toString()}>
              {(provided) => (
                <div
                  {...provided.droppableProps}
                  ref={provided.innerRef}
                  style={{ minHeight: "500px" }}
                >
                  {organizedAssets[zone.zoneId]?.map((asset, index) => (
                    <Draggable
                      key={asset.assetId}
                      draggableId={asset.assetId.toString()}
                      index={index}
                    >
                      {(provided) => (
                        <Card
                          ref={provided.innerRef}
                          {...provided.draggableProps}
                          {...provided.dragHandleProps}
                          sx={{
                            mb: 2,
                            bgcolor: getCardColor(asset.type),
                            "&:hover": {
                              boxShadow: 3,
                              transform: "translateY(-2px)",
                              transition: "all 0.2s",
                            },
                          }}
                        >
                          <CardContent>
                            <Typography variant="h6" component="div">
                              {asset.assetName}
                            </Typography>
                            <Typography color="textSecondary" gutterBottom>
                              {asset.description}
                            </Typography>
                            <Box
                              sx={{
                                display: "flex",
                                justifyContent: "space-between",
                                alignItems: "center",
                                mt: 1,
                              }}
                            >
                              <Chip
                                label={asset.type}
                                size="small"
                                sx={{ borderRadius: 1 }}
                              />
                              <Box>
                                <Tooltip title="Edit Asset">
                                  <IconButton size="small">
                                    <EditIcon fontSize="small" />
                                  </IconButton>
                                </Tooltip>
                                <Tooltip title="Delete Asset">
                                  <IconButton size="small" color="error">
                                    <DeleteIcon fontSize="small" />
                                  </IconButton>
                                </Tooltip>
                              </Box>
                            </Box>
                          </CardContent>
                        </Card>
                      )}
                    </Draggable>
                  ))}
                  {provided.placeholder}
                </div>
              )}
            </Droppable>
          </Paper>
        ))}
      </Box>
    </DragDropContext>
  );
};

export default AssetKanban;
