import { Container, Paper } from "@mui/material";
import Header from "./Header";

const Layout = ({ children }) => {
  return (
    <div>
      <Header />
      <Container maxWidth="lg" sx={{ mt: 4, mb: 4 }}>
        <Paper sx={{ p: 3 }}>{children}</Paper>
      </Container>
    </div>
  );
};

export default Layout;
