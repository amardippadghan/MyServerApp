import { createSlice, createAsyncThunk } from "@reduxjs/toolkit";
import api from "../services/api";

export const fetchAssets = createAsyncThunk("assets/fetchAssets", async () => {
  const response = await api.get("/assets");
  return response.data.data;
});

export const updateAsset = createAsyncThunk(
  "assets/updateAsset",
  async ({ id, ...updateData }) => {
    const response = await api.put(`/assets/${id}`, updateData);
    return response.data.data;
  }
);

export const createAsset = createAsyncThunk(
  "assets/createAsset",
  async (assetData) => {
    const response = await api.post("/assets", assetData);
    return response.data.data;
  }
);

export const deleteAsset = createAsyncThunk(
  "assets/deleteAsset",
  async (id) => {
    await api.delete(`/assets/${id}`);
    return id;
  }
);

const initialState = {
  items: [],
  loading: false,
  error: null,
  selectedAsset: null,
};

const assetsSlice = createSlice({
  name: "assets",
  initialState,
  reducers: {
    setSelectedAsset: (state, action) => {
      state.selectedAsset = action.payload;
    },
    clearError: (state) => {
      state.error = null;
    },
  },
  extraReducers: (builder) => {
    builder
      .addCase(fetchAssets.pending, (state) => {
        state.loading = true;
        state.error = null;
      })
      .addCase(fetchAssets.fulfilled, (state, action) => {
        state.loading = false;
        state.items = action.payload;
      })
      .addCase(fetchAssets.rejected, (state, action) => {
        state.loading = false;
        state.error = action.error.message;
      })
      .addCase(updateAsset.fulfilled, (state, action) => {
        const index = state.items.findIndex(
          (asset) => asset.assetId === action.payload.assetId
        );
        if (index !== -1) {
          state.items[index] = action.payload;
        }
      })
      .addCase(createAsset.fulfilled, (state, action) => {
        state.items.push(action.payload);
      })
      .addCase(deleteAsset.fulfilled, (state, action) => {
        state.items = state.items.filter(
          (asset) => asset.assetId !== action.payload
        );
      });
  },
});

export const { setSelectedAsset, clearError } = assetsSlice.actions;
export default assetsSlice.reducer;
