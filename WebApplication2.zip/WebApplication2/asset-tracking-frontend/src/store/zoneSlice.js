import { createSlice, createAsyncThunk } from "@reduxjs/toolkit";
import api from "../services/api";

// Async thunk for fetching zones
export const fetchZones = createAsyncThunk(
  "zones/fetchZones",
  async (_, { rejectWithValue }) => {
    try {
      const response = await api.get("/api/Zone");
      return response.data.data;
    } catch (error) {
      return rejectWithValue(error.response.data);
    }
  }
);

// Async thunk for creating a zone
export const createZone = createAsyncThunk(
  "zones/createZone",
  async (zoneData, { rejectWithValue }) => {
    try {
      const response = await api.post("/api/Zone", zoneData);
      return response.data.data;
    } catch (error) {
      return rejectWithValue(error.response.data);
    }
  }
);

// Async thunk for updating a zone
export const updateZone = createAsyncThunk(
  "zones/updateZone",
  async ({ zoneId, zoneData }, { rejectWithValue }) => {
    try {
      const response = await api.put(`/api/Zone/${zoneId}`, zoneData);
      return response.data.data;
    } catch (error) {
      return rejectWithValue(error.response.data);
    }
  }
);

const zoneSlice = createSlice({
  name: "zones",
  initialState: {
    items: [],
    status: "idle", // 'idle' | 'loading' | 'succeeded' | 'failed'
    error: null,
  },
  reducers: {},
  extraReducers: (builder) => {
    builder
      // Fetch zones
      .addCase(fetchZones.pending, (state) => {
        state.status = "loading";
      })
      .addCase(fetchZones.fulfilled, (state, action) => {
        state.status = "succeeded";
        state.items = action.payload;
      })
      .addCase(fetchZones.rejected, (state, action) => {
        state.status = "failed";
        state.error = action.payload;
      })
      // Create zone
      .addCase(createZone.fulfilled, (state, action) => {
        state.items.push(action.payload);
      })
      // Update zone
      .addCase(updateZone.fulfilled, (state, action) => {
        const index = state.items.findIndex(
          (zone) => zone.zoneId === action.payload.zoneId
        );
        if (index !== -1) {
          state.items[index] = action.payload;
        }
      });
  },
});

export default zoneSlice.reducer;
