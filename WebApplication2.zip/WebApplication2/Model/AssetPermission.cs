namespace MyServerApp.Models
{
    public class AssetPermission
    {
        public int PermissionId { get; set; }
        public int AssetId { get; set; }
        public int UserId { get; set; }
        public bool CanView { get; set; }
        public bool CanUpdate { get; set; }
        public bool CanDelete { get; set; }
        public int CreatedBy { get; set; }
        public DateTime CreatedAt { get; set; }
        public DateTime UpdatedAt { get; set; }
    }
}