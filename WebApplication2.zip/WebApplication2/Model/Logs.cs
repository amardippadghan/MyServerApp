﻿namespace MyServerApp.Models
{
    public class Logs
    {
        public int LogId { get; set; }
        public int AssetId { get; set; }
        public int Id { get; set; }
        public int ZoneId { get; set; }
        public DateTime TimestampedData { get; set; }
        public DateTime CreatedAt { get; set; }
        public DateTime UpdatedAt { get; set; }
    }
}
