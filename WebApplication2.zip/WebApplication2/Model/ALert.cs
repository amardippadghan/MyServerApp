﻿namespace MyServerApp.Models
{
    public class Alert
    {
        public int AlertId { get; set; }
        public int assetId { get; set; }
        public int ZoneId { get; set; }
        public string AlertMessage { get; set; } = string.Empty;
        public DateTime CreatedAt { get; set; }
    }
}
