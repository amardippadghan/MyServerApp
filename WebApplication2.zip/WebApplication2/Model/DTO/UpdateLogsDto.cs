﻿namespace MyServerApp.Models.DTOs
{
    public class UpdateLogsDto
    {
        public int? AssetId { get; set; }
        public int? Id { get; set; }
        public int? ZoneId { get; set; }
        public DateTime? TimestampedData { get; set; }
    }
}
