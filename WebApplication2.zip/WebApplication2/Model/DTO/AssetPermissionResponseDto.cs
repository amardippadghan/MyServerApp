namespace MyServerApp.Models.DTOs
{
    public class AssetPermissionResponseDto : BaseResponseDto
    {
        public int PermissionId { get; set; }
        public int AssetId { get; set; }
        public int UserId { get; set; }
        public bool CanView { get; set; }
        public bool CanUpdate { get; set; }
        public bool CanDelete { get; set; }
        public int CreatedBy { get; set; }
    }
}