﻿namespace MyServerApp.Models.DTOs
{
    public class UpdateAlertDto
    {
        public int? assetId { get; set; }
        public int? ZoneId { get; set; }
        public string? AlertMessage { get; set; }
        public DateTime? CreatedAt { get; set; }
    }
}
