namespace MyServerApp.Models.DTOs
{
    public static class ResponseMessages
    {
        // Auth messages
        public const string LoginSuccess = "Login successful";
        public const string LoginFailed = "Invalid email or password";
        public const string RegisterSuccess = "Registration successful";
        public const string EmailAlreadyRegistered = "Email already registered";

        // Asset messages
        public const string AssetCreated = "Asset created successfully";
        public const string AssetUpdated = "Asset updated successfully";
        public const string AssetDeleted = "Asset deleted successfully";
        public const string AssetNotFound = "Asset not found";
        public const string AssetPermissionDenied = "You don't have permission to perform this action";

        // Zone messages
        public const string ZoneCreated = "Zone created successfully";
        public const string ZoneUpdated = "Zone updated successfully";
        public const string ZoneDeleted = "Zone deleted successfully";
        public const string ZoneNotFound = "Zone not found";
        public const string AssetMovedToRestrictedZone = "Alert: Asset moved to restricted zone";

        // Permission messages
        public const string PermissionGranted = "Permission granted successfully";
        public const string PermissionUpdated = "Permission updated successfully";
        public const string PermissionRevoked = "Permission revoked successfully";
        public const string PermissionNotFound = "Permission not found";

        // Log messages
        public const string LogCreated = "Log entry created successfully";
        public const string LogUpdated = "Log entry updated successfully";
        public const string LogDeleted = "Log entry deleted successfully";
        public const string LogNotFound = "Log entry not found";

        // Alert messages
        public const string AlertCreated = "Alert created successfully";
        public const string AlertUpdated = "Alert updated successfully";
        public const string AlertDeleted = "Alert deleted successfully";
        public const string AlertNotFound = "Alert not found";

        // Generic messages
        public const string ServerError = "An error occurred while processing your request";
        public const string ValidationError = "Invalid input data";
        public const string Unauthorized = "Unauthorized access";
        public const string NotFound = "Resource not found";
    }
}