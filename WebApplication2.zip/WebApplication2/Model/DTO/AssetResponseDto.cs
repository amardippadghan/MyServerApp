﻿namespace MyServerApp.Models.DTOs
{
    public class AssetResponseDto : BaseResponseDto
    {
        public int AssetId { get; set; }
        public string AssetName { get; set; } = string.Empty;
        public string? Description { get; set; }
        public string? Type { get; set; }
        public int ZoneId { get; set; }
        public string ZoneName { get; set; } = string.Empty;
        public string ZoneType { get; set; } = string.Empty;
        public new DateTime CreatedAt { get; set; }
        public new DateTime UpdatedAt { get; set; }
    }
}
