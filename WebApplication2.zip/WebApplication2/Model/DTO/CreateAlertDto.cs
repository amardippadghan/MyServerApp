﻿namespace MyServerApp.Models.DTOs
{
    public class CreateAlertDto
    {
        public int assetId { get; set; }
        public int ZoneId { get; set; }
        public string AlertMessage { get; set; } = string.Empty;
        public DateTime? CreatedAt { get; set; } // Optional, defaults to now if not provided
    }
}
