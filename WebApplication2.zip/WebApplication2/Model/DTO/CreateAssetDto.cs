﻿namespace MyServerApp.Models.DTOs
{
    public class CreateAssetDto
    {
        public int AssetId { get; set; } 
        public string AssetName { get; set; } = string.Empty;
        public string? Description { get; set; }
        public string? Type { get; set; }
        public int ZoneId { get; set; }
    }
}
