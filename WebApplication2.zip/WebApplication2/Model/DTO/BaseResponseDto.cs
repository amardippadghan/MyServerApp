namespace MyServerApp.Models.DTOs
{
    public class BaseResponseDto
    {
        public DateTime CreatedAt { get; set; }
        public DateTime UpdatedAt { get; set; }
    }
}