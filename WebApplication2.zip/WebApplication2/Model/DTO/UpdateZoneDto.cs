﻿using System.ComponentModel.DataAnnotations;

namespace MyServerApp.Models.DTOs
{
    public class UpdateZoneDto
    {
        [StringLength(100)]
        public string? Name { get; set; }

        public ZoneType? Type { get; set; }
    }
}
