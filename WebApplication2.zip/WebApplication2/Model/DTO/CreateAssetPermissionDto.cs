namespace MyServerApp.Models.DTOs
{
    public class CreateAssetPermissionDto
    {
        public int AssetId { get; set; }
        public int UserId { get; set; }
        public bool CanView { get; set; } = true;
        public bool CanUpdate { get; set; }
        public bool CanDelete { get; set; }
    }
}