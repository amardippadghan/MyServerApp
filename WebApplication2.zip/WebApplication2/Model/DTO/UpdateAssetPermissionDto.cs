namespace MyServerApp.Models.DTOs
{
    public class UpdateAssetPermissionDto
    {
        public bool CanView { get; set; }
        public bool CanUpdate { get; set; }
        public bool CanDelete { get; set; }
    }
}