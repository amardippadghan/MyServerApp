﻿namespace MyServerApp.Models.DTOs
{
    public class AlertResponseDto : BaseResponseDto
    {
        public int AlertId { get; set; }
        public int assetId { get; set; }
        public int ZoneId { get; set; }
        public string AlertMessage { get; set; } = string.Empty;
    }
}
