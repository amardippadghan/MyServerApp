﻿namespace MyServerApp.Models
{
    public class Asset
    {
        public int AssetId { get; set; }
        public string AssetName { get; set; } = string.Empty;
        public string? Description { get; set; }
        public string? Type { get; set; }
        public int ZoneId { get; set; }
        public DateTime CreatedAt { get; set; }
        public DateTime UpdatedAt { get; set; }
    }
}
