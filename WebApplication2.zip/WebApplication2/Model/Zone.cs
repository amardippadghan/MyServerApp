﻿namespace MyServerApp.Models
{
    public class Zone
    {
        public int ZoneId { get; set; }
        public string ZoneName { get; set; } = string.Empty;
        public ZoneType Type { get; set; }
        public DateTime CreatedAt { get; set; }
        public DateTime UpdatedAt { get; set; }
    }

    public enum ZoneType
    {
        Unrestricted = 0,
        Restricted = 1,
        Storage = 2,
        Office = 3,
        Production = 4,
        Laboratory = 5,
        Warehouse = 6,
        SecurityArea = 7,
        IT = 8,
        Meeting = 9
    }
}
