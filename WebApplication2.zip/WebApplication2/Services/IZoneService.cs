﻿using MyServerApp.Models;
using MyServerApp.Models.DTOs;

namespace MyServerApp.Services
{
    public interface IZoneService
    {
        Task<IEnumerable<ZoneResponseDto>> GetAllZonesAsync();
        Task<ZoneResponseDto?> GetZoneByIdAsync(int id);
        Task<IEnumerable<ZoneResponseDto>> GetZonesByTypeAsync(ZoneType type);
        Task<ZoneResponseDto> CreateZoneAsync(CreateZoneDto dto);
        Task<bool> UpdateZoneAsync(int id, UpdateZoneDto dto);
        Task<bool> DeleteZoneAsync(int id);
    }
}
