﻿using MyServerApp.Models;
using MyServerApp.Models.DTOs;
using MyServerApp.Helper;
using MySqlConnector;
using System.Data;

namespace MyServerApp.Services
{
    public class UserService : IUserService
    {
        private readonly IConfiguration _configuration;

        public UserService(IConfiguration configuration)
        {
            _configuration = configuration;
        }

        public async Task<LoginResponseDto?> LoginAsync(LoginDto dto)
        {
            using var connection = GetConnection();
            await connection.OpenAsync();

            var query = "SELECT * FROM users WHERE email = @Email";
            using var command = new MySqlCommand(query, connection);
            command.Parameters.AddWithValue("@Email", dto.Email);

            using var reader = await command.ExecuteReaderAsync();
            if (await reader.ReadAsync())
            {
                var storedHash = reader.GetString("password");
                if (Helpers.PasswordHelper.VerifyPassword(dto.Password, storedHash))
                {
                    return new LoginResponseDto
                    {
                        Id = reader.GetInt32("id"),
                        Name = reader.GetString("name"),
                        Email = reader.GetString("email"),
                        Type = (UserType)reader.GetInt32("type"),
                        Token = JwtHelper.GenerateJwtToken(
                            reader.GetInt32("id"),
                            reader.GetString("email"),
                            ((UserType)reader.GetInt32("type")).ToString(),
                            _configuration)
                    };
                }
            }
            return null;
        }

        public async Task<UserResponseDto> RegisterAsync(RegisterDto dto)
        {
            using var connection = GetConnection();
            await connection.OpenAsync();

            // Check if email already exists
            var checkQuery = "SELECT COUNT(*) FROM users WHERE email = @Email";
            using var checkCommand = new MySqlCommand(checkQuery, connection);
            checkCommand.Parameters.AddWithValue("@Email", dto.Email);
            var existingCount = Convert.ToInt32(await checkCommand.ExecuteScalarAsync());

            if (existingCount > 0)
            {
                throw new InvalidOperationException("Email already registered");
            }

            var query = @"
                INSERT INTO users (name, email, phone, password, type, created_at, updated_at)
                VALUES (@Name, @Email, @Phone, @Password, @Type, @CreatedAt, @UpdatedAt);
                SELECT LAST_INSERT_ID();";

            using var command = new MySqlCommand(query, connection);
            var now = DateTime.UtcNow;
            var hashedPassword = Helpers.PasswordHelper.HashPassword(dto.Password);

            command.Parameters.AddWithValue("@Name", dto.Name);
            command.Parameters.AddWithValue("@Email", dto.Email);
            command.Parameters.AddWithValue("@Phone", dto.Phone);
            command.Parameters.AddWithValue("@Password", hashedPassword);
            command.Parameters.AddWithValue("@Type", (int)dto.Type);
            command.Parameters.AddWithValue("@CreatedAt", now);
            command.Parameters.AddWithValue("@UpdatedAt", now);

            var id = Convert.ToInt32(await command.ExecuteScalarAsync());

            return new UserResponseDto
            {
                Id = id,
                Name = dto.Name,
                Email = dto.Email,
                Phone = dto.Phone,
                Type = dto.Type,
                CreatedAt = now,
                UpdatedAt = now
            };
        }

        private MySqlConnection GetConnection()
        {
            return new MySqlConnection(_configuration.GetConnectionString("DefaultConnection"));
        }

        public async Task<IEnumerable<UserResponseDto>> GetAllUsersAsync()
        {
            var users = new List<UserResponseDto>();

            using var connection = GetConnection();
            await connection.OpenAsync();

            var query = "SELECT * FROM Users";
            using var command = new MySqlCommand(query, connection);
            using var reader = await command.ExecuteReaderAsync();

            while (await reader.ReadAsync())
            {
                users.Add(MapToUserResponse(reader));
            }

            return users;
        }

        public async Task<UserResponseDto?> GetUserByIdAsync(int id)
        {
            using var connection = GetConnection();
            await connection.OpenAsync();

            var query = "SELECT * FROM Users WHERE Id = @Id";
            using var command = new MySqlCommand(query, connection);
            command.Parameters.AddWithValue("@Id", id);

            using var reader = await command.ExecuteReaderAsync();
            if (await reader.ReadAsync())
            {
                return MapToUserResponse(reader);
            }

            return null;
        }

        public async Task<IEnumerable<UserResponseDto>> GetUsersByTypeAsync(UserType type)
        {
            var users = new List<UserResponseDto>();

            using var connection = GetConnection();
            await connection.OpenAsync();

            var query = "SELECT * FROM Users WHERE Type = @Type";
            using var command = new MySqlCommand(query, connection);
            command.Parameters.AddWithValue("@Type", type.ToString());

            using var reader = await command.ExecuteReaderAsync();
            while (await reader.ReadAsync())
            {
                users.Add(MapToUserResponse(reader));
            }

            return users;
        }

        public async Task<UserResponseDto> CreateUserAsync(CreateUserDto dto)
        {
            using var connection = GetConnection();
            await connection.OpenAsync();

            var query = @"
                INSERT INTO Users (Name, Email, Phone, Password, Type, CreatedAt, UpdatedAt)
                VALUES (@Name, @Email, @Phone, @Password, @Type, NOW(), NOW());
                SELECT LAST_INSERT_ID();";

            using var command = new MySqlCommand(query, connection);
            command.Parameters.AddWithValue("@Name", dto.Name);
            command.Parameters.AddWithValue("@Email", dto.Email);
            command.Parameters.AddWithValue("@Phone", dto.Phone);
            command.Parameters.AddWithValue("@Password", dto.Password);
            command.Parameters.AddWithValue("@Type", dto.Type.ToString());

            var id = Convert.ToInt32(await command.ExecuteScalarAsync());

            return new UserResponseDto
            {
                Id = id,
                Name = dto.Name,
                Email = dto.Email,
                Phone = dto.Phone,
                Type = dto.Type,
                CreatedAt = DateTime.UtcNow,
                UpdatedAt = DateTime.UtcNow
            };
        }

        public async Task<bool> UpdateUserAsync(int id, UpdateUserDto dto)
        {
            using var connection = GetConnection();
            await connection.OpenAsync();

            var query = @"
                UPDATE Users SET 
                    Name = IFNULL(@Name, Name),
                    Email = IFNULL(@Email, Email),
                    Phone = IFNULL(@Phone, Phone),
                    Password = IFNULL(@Password, Password),
                    Type = IFNULL(@Type, Type),
                    UpdatedAt = NOW()
                WHERE Id = @Id";

            using var command = new MySqlCommand(query, connection);
            command.Parameters.AddWithValue("@Id", id);
            command.Parameters.AddWithValue("@Name", (object?)dto.Name ?? DBNull.Value);
            command.Parameters.AddWithValue("@Email", (object?)dto.Email ?? DBNull.Value);
            command.Parameters.AddWithValue("@Phone", (object?)dto.Phone ?? DBNull.Value);
            command.Parameters.AddWithValue("@Password", (object?)dto.Password ?? DBNull.Value);
            command.Parameters.AddWithValue("@Type", dto.Type?.ToString() ?? (object)DBNull.Value);

            var rows = await command.ExecuteNonQueryAsync();
            return rows > 0;
        }

        public async Task<bool> DeleteUserAsync(int id)
        {
            using var connection = GetConnection();
            await connection.OpenAsync();

            var query = "DELETE FROM Users WHERE Id = @Id";
            using var command = new MySqlCommand(query, connection);
            command.Parameters.AddWithValue("@Id", id);

            var rows = await command.ExecuteNonQueryAsync();
            return rows > 0;
        }

        private UserResponseDto MapToUserResponse(MySqlDataReader reader)
        {
            return new UserResponseDto
            {
                Id = reader.GetInt32("id"),
                Name = reader["name"] is DBNull ? string.Empty : reader.GetString("name"),
                Email = reader["email"] is DBNull ? string.Empty : reader.GetString("email"),
                Phone = reader["phone"] is DBNull ? string.Empty : reader.GetString("phone"),
                Type = Enum.TryParse<UserType>(reader["type"]?.ToString(), out var type) ? type : UserType.Worker,
                CreatedAt = reader["created_at"] is DBNull ? DateTime.MinValue : reader.GetDateTime("created_at"),
                UpdatedAt = reader["updated_at"] is DBNull ? DateTime.MinValue : reader.GetDateTime("updated_at")
            };
        }
    }
}