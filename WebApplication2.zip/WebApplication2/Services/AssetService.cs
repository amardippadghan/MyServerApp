﻿using MyServerApp.Models;
using MyServerApp.Models.DTOs;
using MySqlConnector;

namespace MyServerApp.Services
{
    public class AssetService : IAssetService
    {
        private readonly IConfiguration _configuration;
        private readonly IAssetPermissionService _permissionService;
        private readonly IAlertService _alertService;
        private readonly ILogsService _logsService;

        public AssetService(
            IConfiguration configuration,
            IAssetPermissionService permissionService,
            IAlertService alertService,
            ILogsService logsService)
        {
            _configuration = configuration;
            _permissionService = permissionService;
            _alertService = alertService;
            _logsService = logsService;
        }

        private MySqlConnection GetConnection()
        {
            return new MySqlConnection(_configuration.GetConnectionString("DefaultConnection"));
        }

        public async Task<IEnumerable<AssetResponseDto>> GetAllAssetsAsync(int userId, UserType userType)
        {
            var assets = new List<AssetResponseDto>();

            using var connection = GetConnection();
            await connection.OpenAsync();

            string query;
            MySqlCommand command;

            try
            {
                if (userType == UserType.Supervisor)
                {
                    // For supervisors, get all assets with their zone information
                    query = @"SELECT a.*, z.zone_name, z.type as zone_type 
                             FROM assets a
                             LEFT JOIN zones z ON a.zone_id = z.zone_id
                             ORDER BY a.asset_id";
                    command = new MySqlCommand(query, connection);
                }
                else
                {
                    // For workers, only get assets they have permission to view
                    query = @"SELECT a.*, z.zone_name, z.type as zone_type 
                             FROM assets a
                             INNER JOIN asset_permissions p ON a.asset_id = p.asset_id
                             LEFT JOIN zones z ON a.zone_id = z.zone_id
                             WHERE p.user_id = @UserId AND p.can_view = true
                             ORDER BY a.asset_id";
                    command = new MySqlCommand(query, connection);
                    command.Parameters.AddWithValue("@UserId", userId);
                }
            }
            catch (Exception ex)
            {
                throw new Exception($"Error in GetAllAssetsAsync: {ex.Message}");
            }

            using (command)
            {
                using var reader = await command.ExecuteReaderAsync();
                while (await reader.ReadAsync())
                {
                    assets.Add(MapToAssetDto(reader));
                }
            }

            return assets;
        }

        public async Task<AssetResponseDto?> GetAssetByIdAsync(int id, int userId, UserType userType)
        {
            using var connection = GetConnection();
            await connection.OpenAsync();

            string query;
            MySqlCommand command;

            if (userType == UserType.Supervisor)
            {
                query = @"SELECT a.*, z.zone_name, z.type as zone_type 
                         FROM assets a
                         LEFT JOIN zones z ON a.zone_id = z.zone_id
                         WHERE a.asset_id = @AssetId";
                command = new MySqlCommand(query, connection);
                command.Parameters.AddWithValue("@AssetId", id);
            }
            else
            {
                query = @"SELECT a.*, z.zone_name, z.type as zone_type 
                         FROM assets a
                         INNER JOIN asset_permissions p ON a.asset_id = p.asset_id
                         LEFT JOIN zones z ON a.zone_id = z.zone_id
                         WHERE a.asset_id = @AssetId AND p.user_id = @UserId AND p.can_view = true";
                command = new MySqlCommand(query, connection);
                command.Parameters.AddWithValue("@AssetId", id);
                command.Parameters.AddWithValue("@UserId", userId);
            }

            using var reader = await command.ExecuteReaderAsync();
            if (await reader.ReadAsync())
            {
                return MapToAssetDto(reader);
            }

            return null;
        }

        public async Task<AssetResponseDto> CreateAssetAsync(CreateAssetDto dto, int userId, UserType userType)
        {
            if (userType != UserType.Supervisor)
            {
                throw new UnauthorizedAccessException("Only supervisors can create assets");
            }

            using var connection = GetConnection();
            await connection.OpenAsync();

            var query = @"
                INSERT INTO assets (asset_name, description, type, zone_id, created_at, updated_at)
                VALUES (@AssetName, @Description, @Type, @ZoneId, @CreatedAt, @UpdatedAt);
                SELECT LAST_INSERT_ID();";

            using var command = new MySqlCommand(query, connection);
            var now = DateTime.UtcNow;
            command.Parameters.AddWithValue("@AssetName", dto.AssetName);
            command.Parameters.AddWithValue("@Description", (object?)dto.Description ?? DBNull.Value);
            command.Parameters.AddWithValue("@Type", (object?)dto.Type ?? DBNull.Value);
            command.Parameters.AddWithValue("@ZoneId", dto.ZoneId);
            command.Parameters.AddWithValue("@CreatedAt", now);
            command.Parameters.AddWithValue("@UpdatedAt", now);

            var assetId = Convert.ToInt32(await command.ExecuteScalarAsync());

            return new AssetResponseDto
            {
                AssetId = assetId,
                AssetName = dto.AssetName,
                Description = dto.Description,
                Type = dto.Type,
                ZoneId = dto.ZoneId,
                CreatedAt = now,
                UpdatedAt = now
            };
        }



        public async Task<bool> UpdateAssetAsync(int id, UpdateAssetDto dto, int userId, UserType userType)
        {
            // For workers, check permissions
            if (userType == UserType.Worker)
            {
                var permission = await _permissionService.GetPermissionAsync(id, userId);
                if (permission == null || !permission.CanUpdate)
                {
                    return false;
                }
            }

            // For both worker and supervisor, check if asset exists
            var currentAsset = await GetAssetByIdAsync(id, userId, userType);
            if (currentAsset == null)
            {
                return false;
            }

            using var connection = GetConnection();
            await connection.OpenAsync();

            // Get zone type of the new zone
            var zoneQuery = "SELECT type FROM zones1 WHERE zone_id = @ZoneId";
            using var zoneCommand = new MySqlCommand(zoneQuery, connection);
            zoneCommand.Parameters.AddWithValue("@ZoneId", dto.ZoneId);
            var newZoneType = (ZoneType)Convert.ToInt32(await zoneCommand.ExecuteScalarAsync());

            // Get current zone type
            var currentZoneQuery = "SELECT z.type FROM zones1 z INNER JOIN assets a ON z.zone_id = a.zone_id WHERE a.asset_id = @AssetId";
            using var currentZoneCommand = new MySqlCommand(currentZoneQuery, connection);
            currentZoneCommand.Parameters.AddWithValue("@AssetId", id);
            var currentZoneType = (ZoneType)Convert.ToInt32(await currentZoneCommand.ExecuteScalarAsync());

            var query = @"
                UPDATE assets SET 
                    asset_name = IFNULL(@AssetName, asset_name),
                    description = IFNULL(@Description, description),
                    type = IFNULL(@Type, type),
                    zone_id = IFNULL(@ZoneId, zone_id),
                    updated_at = @UpdatedAt
                WHERE asset_id = @AssetId";

            using var command = new MySqlCommand(query, connection);
            command.Parameters.AddWithValue("@AssetId", id);
            command.Parameters.AddWithValue("@AssetName", (object?)dto.AssetName ?? DBNull.Value);
            command.Parameters.AddWithValue("@UpdatedAt", DateTime.UtcNow);
            command.Parameters.AddWithValue("@Description", (object?)dto.Description ?? DBNull.Value);
            command.Parameters.AddWithValue("@Type", (object?)dto.Type ?? DBNull.Value);
            command.Parameters.AddWithValue("@ZoneId", dto.ZoneId);

            var rows = await command.ExecuteNonQueryAsync();
            return rows > 0;
        }

        public async Task<bool> DeleteAssetAsync(int id, int userId, UserType userType)
        {
            // For workers, check permissions
            if (userType == UserType.Worker)
            {
                var permission = await _permissionService.GetPermissionAsync(id, userId);
                if (permission == null || !permission.CanDelete)
                {
                    return false;
                }
            }

            using var connection = GetConnection();
            await connection.OpenAsync();

            var query = "DELETE FROM assets WHERE asset_id = @AssetId";
            using var command = new MySqlCommand(query, connection);
            command.Parameters.AddWithValue("@AssetId", id);

            var rows = await command.ExecuteNonQueryAsync();
            return rows > 0;
        }

        private AssetResponseDto MapToAssetDto(MySqlDataReader reader)
        {
            return new AssetResponseDto
            {
                AssetId = Convert.ToInt32(reader["asset_id"]),
                AssetName = reader["asset_name"].ToString() ?? string.Empty,
                Description = reader["description"] is DBNull ? null : reader["description"].ToString(),
                Type = reader["type"] is DBNull ? null : reader["type"].ToString(),
                ZoneId = reader["zone_id"] is DBNull ? 0 : Convert.ToInt32(reader["zone_id"]),
                ZoneName = reader["zone_name"] is DBNull ? string.Empty : reader["zone_name"].ToString() ?? string.Empty,
                ZoneType = reader["zone_type"] is DBNull ? string.Empty : ((ZoneType)Convert.ToInt32(reader["zone_type"])).ToString(),
                CreatedAt = reader["created_at"] is DBNull ? DateTime.UtcNow : Convert.ToDateTime(reader["created_at"]),
                UpdatedAt = reader["updated_at"] is DBNull ? DateTime.UtcNow : Convert.ToDateTime(reader["updated_at"])
            };
        }
    }
}
