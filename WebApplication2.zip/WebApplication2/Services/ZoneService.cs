﻿using MyServerApp.Models;
using MyServerApp.Models.DTOs;
using MySqlConnector;

namespace MyServerApp.Services
{
    public class ZoneService : IZoneService
    {
        private readonly IConfiguration _configuration;

        public ZoneService(IConfiguration configuration)
        {
            _configuration = configuration;
        }

        private MySqlConnection GetConnection() =>
            new MySqlConnection(_configuration.GetConnectionString("DefaultConnection"));

        public async Task<IEnumerable<ZoneResponseDto>> GetAllZonesAsync()
        {
            var zones = new List<ZoneResponseDto>();
            using var conn = GetConnection();
            await conn.OpenAsync();

            var query = "SELECT zone_id, zone_name, type, created_at, updated_at FROM zones";
            using var cmd = new MySqlCommand(query, conn);
            using var reader = await cmd.ExecuteReaderAsync();

            while (await reader.ReadAsync())
            {
                zones.Add(new ZoneResponseDto
                {
                    Id = reader.GetInt32("zone_id"),
                    Name = reader["zone_name"] as string ?? string.Empty,
                    Type = ((ZoneType)reader.GetInt32("type")).ToString(),
                    CreatedAt = reader["created_at"] is DBNull ? DateTime.UtcNow : reader.GetDateTime("created_at"),
                    UpdatedAt = reader["updated_at"] is DBNull ? DateTime.UtcNow : reader.GetDateTime("updated_at")
                });
            }

            return zones;
        }

        public async Task<ZoneResponseDto?> GetZoneByIdAsync(int id)
        {
            using var conn = GetConnection();
            await conn.OpenAsync();

            var query = "SELECT zone_id, zone_name, created_at, updated_at FROM zones WHERE zone_id = @id";
            using var cmd = new MySqlCommand(query, conn);
            cmd.Parameters.AddWithValue("@id", id);

            using var reader = await cmd.ExecuteReaderAsync();
            if (await reader.ReadAsync())
            {
                return new ZoneResponseDto
                {
                    Id = reader.GetInt32("zone_id"),
                    Name = reader["zone_name"] as string ?? string.Empty,
                    Type = ""
                };
            }

            return null;
        }

        public async Task<IEnumerable<ZoneResponseDto>> GetZonesByTypeAsync(ZoneType type)
        {
            var zones = new List<ZoneResponseDto>();

            using var connection = GetConnection();
            await connection.OpenAsync();

            var query = "SELECT zone_id, zone_name, type, created_at, updated_at FROM zones WHERE type = @type";
            using var cmd = new MySqlCommand(query, connection);
            cmd.Parameters.AddWithValue("@type", (int)type);

            using var reader = await cmd.ExecuteReaderAsync();
            while (await reader.ReadAsync())
            {
                zones.Add(new ZoneResponseDto
                {
                    Id = reader.GetInt32("zone_id"),
                    Name = reader["zone_name"] as string ?? string.Empty,
                    Type = ((ZoneType)reader.GetInt32("type")).ToString(),
                    CreatedAt = reader["created_at"] is DBNull ? DateTime.UtcNow : reader.GetDateTime("created_at"),
                    UpdatedAt = reader["updated_at"] is DBNull ? DateTime.UtcNow : reader.GetDateTime("updated_at")
                });
            }

            return zones;
        }

        public async Task<ZoneResponseDto> CreateZoneAsync(CreateZoneDto dto)
        {
            using var conn = GetConnection();
            await conn.OpenAsync();

            var query = "INSERT INTO zones (zone_name, type) VALUES (@name, @type); SELECT LAST_INSERT_ID();";
            using var cmd = new MySqlCommand(query, conn);
            cmd.Parameters.AddWithValue("@name", dto.Name);
            cmd.Parameters.AddWithValue("@type", (int)dto.Type);

            var id = Convert.ToInt32(await cmd.ExecuteScalarAsync());

            return new ZoneResponseDto
            {
                Id = id,
                Name = dto.Name,
                Type = dto.Type.ToString()
            };
        }

        public async Task<bool> UpdateZoneAsync(int id, UpdateZoneDto dto)
        {
            using var conn = GetConnection();
            await conn.OpenAsync();

            var query = "UPDATE zones SET zone_name = COALESCE(@name, zone_name), type = COALESCE(@type, type) WHERE zone_id = @id";
            using var cmd = new MySqlCommand(query, conn);
            cmd.Parameters.AddWithValue("@id", id);
            cmd.Parameters.AddWithValue("@name", dto.Name ?? (object)DBNull.Value);
            cmd.Parameters.AddWithValue("@type", dto.Type.HasValue ? (int)dto.Type.Value : (object)DBNull.Value);

            var rows = await cmd.ExecuteNonQueryAsync();
            return rows > 0;
        }

        public async Task<bool> DeleteZoneAsync(int id)
        {
            using var conn = GetConnection();
            await conn.OpenAsync();

            var query = "DELETE FROM zones WHERE zone_id = @id";
            using var cmd = new MySqlCommand(query, conn);
            cmd.Parameters.AddWithValue("@id", id);

            var rows = await cmd.ExecuteNonQueryAsync();
            return rows > 0;
        }
    }
}
