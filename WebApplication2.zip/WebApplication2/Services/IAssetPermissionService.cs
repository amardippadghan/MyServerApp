using MyServerApp.Models.DTOs;

namespace MyServerApp.Services
{
    public interface IAssetPermissionService
    {
        Task<AssetPermissionResponseDto> CreatePermissionAsync(CreateAssetPermissionDto dto, int supervisorId);
        Task<bool> UpdatePermissionAsync(int permissionId, UpdateAssetPermissionDto dto, int supervisorId);
        Task<bool> DeletePermissionAsync(int permissionId, int supervisorId);
        Task<IEnumerable<AssetPermissionResponseDto>> GetUserPermissionsAsync(int userId);
        Task<AssetPermissionResponseDto?> GetPermissionAsync(int assetId, int userId);
        Task<bool> HasPermissionAsync(int assetId, int userId, string permissionType);
    }
}