﻿using MyServerApp.Models;
using MyServerApp.Models.DTOs;

public interface IUserService
{
    Task<IEnumerable<UserResponseDto>> GetAllUsersAsync();
    Task<UserResponseDto?> GetUserByIdAsync(int id);
    Task<IEnumerable<UserResponseDto>> GetUsersByTypeAsync(UserType type);
    Task<UserResponseDto> CreateUserAsync(CreateUserDto dto);
    Task<bool> UpdateUserAsync(int id, UpdateUserDto dto);
    Task<bool> DeleteUserAsync(int id);
    Task<LoginResponseDto?> LoginAsync(LoginDto dto);
    Task<UserResponseDto> RegisterAsync(RegisterDto dto);
}
