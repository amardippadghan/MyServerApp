﻿using MyServerApp.Models;
using MyServerApp.Models.DTOs;
using MySqlConnector;

namespace MyServerApp.Services
{
    public class AlertsService : IAlertService
    {
        private readonly IConfiguration _configuration;

        public AlertsService(IConfiguration configuration)
        {
            _configuration = configuration;
        }

        private MySqlConnection GetConnection()
        {
            return new MySqlConnection(_configuration.GetConnectionString("DefaultConnection"));
        }

        public async Task<IEnumerable<AlertResponseDto>> GetAllAlertsAsync()
        {
            var alerts = new List<AlertResponseDto>();

            using var connection = GetConnection();
            await connection.OpenAsync();

            var query = "SELECT * FROM alerts";
            using var command = new MySqlCommand(query, connection);
            using var reader = await command.ExecuteReaderAsync();

            while (await reader.ReadAsync())
            {
                alerts.Add(MapToAlertResponse(reader));
            }

            return alerts;
        }

        public async Task<AlertResponseDto?> GetAlertByIdAsync(int alertId)
        {
            using var connection = GetConnection();
            await connection.OpenAsync();

            var query = "SELECT * FROM alerts WHERE alert_id = @alert_id";
            using var command = new MySqlCommand(query, connection);
            command.Parameters.AddWithValue("@alert_id", alertId);

            using var reader = await command.ExecuteReaderAsync();
            if (await reader.ReadAsync())
            {
                return MapToAlertResponse(reader);
            }

            return null;
        }

        public async Task<AlertResponseDto> CreateAlertAsync(CreateAlertDto dto)
        {
            using var connection = GetConnection();
            await connection.OpenAsync();

            var query = @"
                INSERT INTO alerts (asset_id, zone_id, alert_message, created_at, updated_at)
                VALUES (@asset_id, @zone_id, @alert_message, @created_at, @updated_at);
                SELECT LAST_INSERT_ID();";

            using var command = new MySqlCommand(query, connection);
            var now = DateTime.UtcNow;
            command.Parameters.AddWithValue("@asset_id", dto.assetId);
            command.Parameters.AddWithValue("@zone_id", dto.ZoneId);
            command.Parameters.AddWithValue("@alert_message", dto.AlertMessage);
            command.Parameters.AddWithValue("@created_at", now);
            command.Parameters.AddWithValue("@updated_at", now);

            var alertId = Convert.ToInt32(await command.ExecuteScalarAsync());

            return new AlertResponseDto
            {
                AlertId = alertId,
                assetId = dto.assetId,
                ZoneId = dto.ZoneId,
                AlertMessage = dto.AlertMessage,
                CreatedAt = dto.CreatedAt ?? DateTime.UtcNow
            };
        }

        public async Task<bool> UpdateAlertAsync(int alertId, UpdateAlertDto dto)
        {
            using var connection = GetConnection();
            await connection.OpenAsync();

            var query = @"
                UPDATE alerts SET 
                    asset_id = IFNULL(@asset_id, asset_id),
                    zone_id = IFNULL(@zone_id, zone_id),
                    alert_message = IFNULL(@alert_message, alert_message),
                    created_at = IFNULL(@created_at, created_at)
                WHERE alert_id = @alert_id";

            using var command = new MySqlCommand(query, connection);
            command.Parameters.AddWithValue("@alert_id", alertId);
            command.Parameters.AddWithValue("@asset_id", dto.assetId.HasValue ? (object)dto.assetId.Value : DBNull.Value);
            command.Parameters.AddWithValue("@zone_id", dto.ZoneId.HasValue ? (object)dto.ZoneId.Value : DBNull.Value);
            command.Parameters.AddWithValue("@alert_message", dto.AlertMessage ?? (object)DBNull.Value);
            command.Parameters.AddWithValue("@created_at", dto.CreatedAt ?? (object)DBNull.Value);

            var rows = await command.ExecuteNonQueryAsync();
            return rows > 0;
        }

        public async Task<bool> DeleteAlertAsync(int alertId)
        {
            using var connection = GetConnection();
            await connection.OpenAsync();

            var query = "DELETE FROM alerts WHERE alert_id = @alert_id";
            using var command = new MySqlCommand(query, connection);
            command.Parameters.AddWithValue("@alert_id", alertId);

            var rows = await command.ExecuteNonQueryAsync();
            return rows > 0;
        }

        private AlertResponseDto MapToAlertResponse(MySqlDataReader reader)
        {
            return new AlertResponseDto
            {
                AlertId = reader.GetInt32("alert_id"),
                assetId = reader["asset_id"] is DBNull ? 0 : reader.GetInt32("asset_id"),
                ZoneId = reader["zone_id"] is DBNull ? 0 : reader.GetInt32("zone_id"),
                AlertMessage = reader["alert_message"] is DBNull ? string.Empty : reader.GetString("alert_message"),
                CreatedAt = reader["created_at"] is DBNull ? DateTime.UtcNow : reader.GetDateTime("created_at"),
                UpdatedAt = reader["updated_at"] is DBNull ? DateTime.UtcNow : reader.GetDateTime("updated_at")
            };
        }
    }
}
