﻿using MyServerApp.Models.DTOs;
using MySqlConnector;

namespace MyServerApp.Services
{
    public class LogsService : ILogsService
    {
        private readonly IConfiguration _configuration;

        public LogsService(IConfiguration configuration)
        {
            _configuration = configuration;
        }

        private MySqlConnection GetConnection()
        {
            return new MySqlConnection(_configuration.GetConnectionString("DefaultConnection"));
        }

        public async Task<IEnumerable<LogsResponseDto>> GetAllLogsAsync()
        {
            var logs = new List<LogsResponseDto>();

            using var connection = GetConnection();
            await connection.OpenAsync();

            var query = "SELECT * FROM logs3";
            using var command = new MySqlCommand(query, connection);
            using var reader = await command.ExecuteReaderAsync();

            while (await reader.ReadAsync())
            {
                logs.Add(MapToLogs2Response(reader));
            }

            return logs;
        }

        public async Task<LogsResponseDto?> GetLogByIdAsync(int log_id)
        {
            using var connection = GetConnection();
            await connection.OpenAsync();

            var query = "SELECT * FROM logs3 WHERE log_id = @log_id";
            using var command = new MySqlCommand(query, connection);
            command.Parameters.AddWithValue("@log_id", log_id);

            using var reader = await command.ExecuteReaderAsync();
            if (await reader.ReadAsync())
            {
                return MapToLogs2Response(reader);
            }

            return null;
        }

        public async Task<LogsResponseDto> CreateLogAsync(CreateLogsDto dto)
        {
            using var connection = GetConnection();
            await connection.OpenAsync();

            var query = @"
                INSERT INTO logs3 (asset_id, Id, zone_id, timestamped_data, created_at, updated_at)
                VALUES (@asset_id, @Id, @zone_id, @timestamped_data, @created_at, @updated_at);
                SELECT LAST_INSERT_ID();";

            using var command = new MySqlCommand(query, connection);
            var now = DateTime.UtcNow;
            command.Parameters.AddWithValue("@asset_id", dto.AssetId);
            command.Parameters.AddWithValue("@Id", dto.Id);
            command.Parameters.AddWithValue("@zone_id", dto.ZoneId);
            command.Parameters.AddWithValue("@timestamped_data", dto.TimestampedData ?? now);
            command.Parameters.AddWithValue("@created_at", now);
            command.Parameters.AddWithValue("@updated_at", now);

            var log_id = Convert.ToInt32(await command.ExecuteScalarAsync());

            return new LogsResponseDto
            {
                LogId = log_id,
                AssetId = dto.AssetId,
                Id = dto.Id,
                ZoneId = dto.ZoneId,
                CreatedAt = now,
                UpdatedAt = now,
                TimestampedData = dto.TimestampedData ?? DateTime.UtcNow
            };
        }

        public async Task<bool> UpdateLogAsync(int log_id, UpdateLogsDto dto)
        {
            using var connection = GetConnection();
            await connection.OpenAsync();

            var query = @"
                UPDATE logs3 SET 
                    asset_id = IFNULL(@asset_id, asset_id),
                    Id = IFNULL(@Id, Id),
                    zone_id = IFNULL(@zone_id, zone_id),
                    timestamped_data = IFNULL(@timestamped_data, timestamped_data)
                WHERE log_id = @log_id";

            using var command = new MySqlCommand(query, connection);
            command.Parameters.AddWithValue("@log_id", log_id);
            command.Parameters.AddWithValue("@asset_id", dto.AssetId.HasValue ? (object)dto.AssetId.Value : DBNull.Value);
            command.Parameters.AddWithValue("@Id", dto.Id.HasValue ? (object)dto.Id.Value : DBNull.Value);
            command.Parameters.AddWithValue("@zone_id", dto.ZoneId.HasValue ? (object)dto.ZoneId.Value : DBNull.Value);
            command.Parameters.AddWithValue("@timestamped_data", dto.TimestampedData ?? (object)DBNull.Value);

            var rows = await command.ExecuteNonQueryAsync();
            return rows > 0;
        }

        public async Task<bool> DeleteLogAsync(int log_id)
        {
            using var connection = GetConnection();
            await connection.OpenAsync();

            var query = "DELETE FROM logs3 WHERE log_id = @log_id";
            using var command = new MySqlCommand(query, connection);
            command.Parameters.AddWithValue("@log_id", log_id);

            var rows = await command.ExecuteNonQueryAsync();
            return rows > 0;
        }

        private LogsResponseDto MapToLogs2Response(MySqlDataReader reader)
        {
            return new LogsResponseDto
            {
                LogId = reader.GetInt32("log_id"),
                AssetId = reader["asset_id"] is DBNull ? 0 : reader.GetInt32("asset_id"),
                Id = reader["Id"] is DBNull ? 0 : reader.GetInt32("Id"),
                ZoneId = reader["zone_id"] is DBNull ? 0 : reader.GetInt32("zone_id"),
                TimestampedData = reader["timestamped_data"] is DBNull ? DateTime.MinValue : reader.GetDateTime("timestamped_data"),
                CreatedAt = reader["created_at"] is DBNull ? DateTime.UtcNow : reader.GetDateTime("created_at"),
                UpdatedAt = reader["updated_at"] is DBNull ? DateTime.UtcNow : reader.GetDateTime("updated_at")
            };
        }
    }
}
