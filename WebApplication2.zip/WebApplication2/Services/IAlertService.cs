﻿using MyServerApp.Models.DTOs;

namespace MyServerApp.Services
{
    public interface IAlertService
    {
        Task<IEnumerable<AlertResponseDto>> GetAllAlertsAsync();
        Task<AlertResponseDto?> GetAlertByIdAsync(int alertId);
        Task<AlertResponseDto> CreateAlertAsync(CreateAlertDto dto);
        Task<bool> UpdateAlertAsync(int alertId, UpdateAlertDto dto);
        Task<bool> DeleteAlertAsync(int alertId);
    }
}
