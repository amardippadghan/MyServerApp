﻿using MyServerApp.Models;
using MyServerApp.Models.DTOs;

namespace MyServerApp.Services
{
    public interface IAssetService
    {
        Task<IEnumerable<AssetResponseDto>> GetAllAssetsAsync(int userId, UserType userType);
        Task<AssetResponseDto?> GetAssetByIdAsync(int id, int userId, UserType userType);
        Task<AssetResponseDto> CreateAssetAsync(CreateAssetDto dto, int userId, UserType userType);
        Task<bool> UpdateAssetAsync(int id, UpdateAssetDto dto, int userId, UserType userType);
        Task<bool> DeleteAssetAsync(int id, int userId, UserType userType);
    }
}
