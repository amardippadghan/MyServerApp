using MyServerApp.Models;
using MyServerApp.Models.DTOs;
using MySqlConnector;

namespace MyServerApp.Services
{
    public class AssetPermissionService : IAssetPermissionService
    {
        private readonly IConfiguration _configuration;

        public AssetPermissionService(IConfiguration configuration)
        {
            _configuration = configuration;
        }

        private MySqlConnection GetConnection()
        {
            return new MySqlConnection(_configuration.GetConnectionString("DefaultConnection"));
        }

        public async Task<AssetPermissionResponseDto> CreatePermissionAsync(CreateAssetPermissionDto dto, int supervisorId)
        {
            using var connection = GetConnection();
            await connection.OpenAsync();

            var query = @"
                INSERT INTO asset_permissions (asset_id, user_id, can_view, can_update, can_delete, created_by, created_at, updated_at)
                VALUES (@AssetId, @UserId, @CanView, @CanUpdate, @CanDelete, @CreatedBy, @CreatedAt, @UpdatedAt);
                SELECT LAST_INSERT_ID();";

            using var command = new MySqlCommand(query, connection);
            var now = DateTime.UtcNow;
            command.Parameters.AddWithValue("@AssetId", dto.AssetId);
            command.Parameters.AddWithValue("@UserId", dto.UserId);
            command.Parameters.AddWithValue("@CanView", dto.CanView);
            command.Parameters.AddWithValue("@CanUpdate", dto.CanUpdate);
            command.Parameters.AddWithValue("@CanDelete", dto.CanDelete);
            command.Parameters.AddWithValue("@CreatedBy", supervisorId);
            command.Parameters.AddWithValue("@CreatedAt", now);
            command.Parameters.AddWithValue("@UpdatedAt", now);

            var permissionId = Convert.ToInt32(await command.ExecuteScalarAsync());

            return new AssetPermissionResponseDto
            {
                PermissionId = permissionId,
                AssetId = dto.AssetId,
                UserId = dto.UserId,
                CanView = dto.CanView,
                CanUpdate = dto.CanUpdate,
                CanDelete = dto.CanDelete,
                CreatedBy = supervisorId,
                CreatedAt = now,
                UpdatedAt = now
            };
        }

        public async Task<bool> UpdatePermissionAsync(int permissionId, UpdateAssetPermissionDto dto, int supervisorId)
        {
            using var connection = GetConnection();
            await connection.OpenAsync();

            var query = @"
                UPDATE asset_permissions 
                SET can_view = @CanView,
                    can_update = @CanUpdate,
                    can_delete = @CanDelete,
                    updated_at = @UpdatedAt
                WHERE permission_id = @PermissionId 
                AND created_by = @SupervisorId";

            using var command = new MySqlCommand(query, connection);
            command.Parameters.AddWithValue("@PermissionId", permissionId);
            command.Parameters.AddWithValue("@CanView", dto.CanView);
            command.Parameters.AddWithValue("@CanUpdate", dto.CanUpdate);
            command.Parameters.AddWithValue("@CanDelete", dto.CanDelete);
            command.Parameters.AddWithValue("@UpdatedAt", DateTime.UtcNow);
            command.Parameters.AddWithValue("@SupervisorId", supervisorId);

            var rowsAffected = await command.ExecuteNonQueryAsync();
            return rowsAffected > 0;
        }

        public async Task<bool> DeletePermissionAsync(int permissionId, int supervisorId)
        {
            using var connection = GetConnection();
            await connection.OpenAsync();

            var query = "DELETE FROM asset_permissions WHERE permission_id = @PermissionId AND created_by = @SupervisorId";

            using var command = new MySqlCommand(query, connection);
            command.Parameters.AddWithValue("@PermissionId", permissionId);
            command.Parameters.AddWithValue("@SupervisorId", supervisorId);

            var rowsAffected = await command.ExecuteNonQueryAsync();
            return rowsAffected > 0;
        }

        public async Task<IEnumerable<AssetPermissionResponseDto>> GetUserPermissionsAsync(int userId)
        {
            var permissions = new List<AssetPermissionResponseDto>();

            using var connection = GetConnection();
            await connection.OpenAsync();

            var query = "SELECT * FROM asset_permissions WHERE user_id = @UserId";
            using var command = new MySqlCommand(query, connection);
            command.Parameters.AddWithValue("@UserId", userId);

            using var reader = await command.ExecuteReaderAsync();
            while (await reader.ReadAsync())
            {
                permissions.Add(MapToPermissionResponse(reader));
            }

            return permissions;
        }

        public async Task<AssetPermissionResponseDto?> GetPermissionAsync(int assetId, int userId)
        {
            using var connection = GetConnection();
            await connection.OpenAsync();

            var query = "SELECT * FROM asset_permissions WHERE asset_id = @AssetId AND user_id = @UserId";
            using var command = new MySqlCommand(query, connection);
            command.Parameters.AddWithValue("@AssetId", assetId);
            command.Parameters.AddWithValue("@UserId", userId);

            using var reader = await command.ExecuteReaderAsync();
            if (await reader.ReadAsync())
            {
                return MapToPermissionResponse(reader);
            }

            return null;
        }

        public async Task<bool> HasPermissionAsync(int assetId, int userId, string permissionType)
        {
            using var connection = GetConnection();
            await connection.OpenAsync();

            var columnName = permissionType.ToLower() switch
            {
                "view" => "can_view",
                "update" => "can_update",
                "delete" => "can_delete",
                _ => throw new ArgumentException("Invalid permission type")
            };

            var query = $"SELECT {columnName} FROM asset_permissions WHERE asset_id = @AssetId AND user_id = @UserId";
            using var command = new MySqlCommand(query, connection);
            command.Parameters.AddWithValue("@AssetId", assetId);
            command.Parameters.AddWithValue("@UserId", userId);

            var result = await command.ExecuteScalarAsync();
            return result != null && Convert.ToBoolean(result);
        }

        private AssetPermissionResponseDto MapToPermissionResponse(MySqlDataReader reader)
        {
            return new AssetPermissionResponseDto
            {
                PermissionId = reader.GetInt32("permission_id"),
                AssetId = reader.GetInt32("asset_id"),
                UserId = reader.GetInt32("user_id"),
                CanView = reader.GetBoolean("can_view"),
                CanUpdate = reader.GetBoolean("can_update"),
                CanDelete = reader.GetBoolean("can_delete"),
                CreatedBy = reader.GetInt32("created_by"),
                CreatedAt = reader.GetDateTime("created_at"),
                UpdatedAt = reader.GetDateTime("updated_at")
            };
        }
    }
}