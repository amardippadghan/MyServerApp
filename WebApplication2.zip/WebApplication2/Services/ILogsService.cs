﻿using MyServerApp.Models.DTOs;

namespace MyServerApp.Services
{
    public interface ILogsService
    {
        Task<IEnumerable<LogsResponseDto>> GetAllLogsAsync();
        Task<LogsResponseDto?> GetLogByIdAsync(int log_id);
        Task<LogsResponseDto> CreateLogAsync(CreateLogsDto dto);
        Task<bool> UpdateLogAsync(int log_id, UpdateLogsDto dto);
        Task<bool> DeleteLogAsync(int log_id);
    }
}
