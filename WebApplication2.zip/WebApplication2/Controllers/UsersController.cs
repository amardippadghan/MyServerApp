﻿using Microsoft.AspNetCore.Mvc;
using MyServerApp.Models;
using MyServerApp.Models.DTOs;
using MyServerApp.Services;
using MySqlConnector;

namespace MyServerApp.Controllers
{
    [ApiController]
    [Route("api/[controller]")]
    public class UsersController : Controller
    {
        private readonly IUserService _userService;
        private readonly IConfiguration _configuration;

        public UsersController(IUserService userService, IConfiguration configuration)
        {
            _userService = userService;
            _configuration = configuration;
        }

        [HttpGet]
        public IActionResult GetAllUsers() =>
            Ok(_userService.GetAllUsersAsync().Result);

        [HttpGet("{id}")]
        public IActionResult GetUserById(int id)
        {
            var user = _userService.GetUserByIdAsync(id).Result;
            return user == null ? NotFound() : Ok(user);
        }

        [HttpPost]
        public IActionResult CreateUser([FromBody] CreateUserDto dto)
        {
            if (dto == null) return BadRequest("User data is null");
            var user = _userService.CreateUserAsync(dto).Result;
            return Ok(new { message = "User added successfully", user });
        }

        [HttpPut("{id}")]
        public IActionResult UpdateUser(int id, [FromBody] UpdateUserDto dto)
        {
            if (!ModelState.IsValid) return BadRequest(ModelState);
            var updated = _userService.UpdateUserAsync(id, dto).Result;
            return updated ? NoContent() : NotFound();
        }

        [HttpDelete("{id}")]
        public IActionResult DeleteUser(int id)
        {
            var deleted = _userService.DeleteUserAsync(id).Result;
            return deleted ? NoContent() : NotFound();
        }

        [HttpGet("test-connection")]
        public IActionResult TestConnection()
        {
            try
            {
                using var conn = new MySqlConnection(_configuration.GetConnectionString("DefaultConnection"));
                conn.Open();
                return Ok(new { message = "Connection successful", timestamp = DateTime.UtcNow });
            }
            catch (Exception ex)
            {
                return StatusCode(500, new { error = ex.Message });
            }
        }
    }
}
