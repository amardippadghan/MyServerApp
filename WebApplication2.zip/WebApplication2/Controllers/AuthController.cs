using Microsoft.AspNetCore.Mvc;
using MyServerApp.Models;
using MyServerApp.Models.DTOs;
using MyServerApp.Services;

namespace MyServerApp.Controllers
{
    [ApiController]
    [Route("api/[controller]")]
    public class AuthController : ControllerBase
    {
        private readonly IUserService _userService;

        public AuthController(IUserService userService)
        {
            _userService = userService;
        }

        [HttpPost("login")]
        public async Task<IActionResult> Login([FromBody] LoginDto dto)
        {
            try
            {
                var user = await _userService.LoginAsync(dto);
                if (user == null)
                {
                    return Ok(ApiResponse<LoginResponseDto>.ErrorResponse(ResponseMessages.LoginFailed));
                }

                return Ok(ApiResponse<LoginResponseDto>.SuccessResponse(user, ResponseMessages.LoginSuccess));
            }
            catch (Exception ex)
            {
                return StatusCode(500, ApiResponse<LoginResponseDto>.ErrorResponse($"An error occurred: {ex.Message}"));
            }
        }

        [HttpPost("register")]
        public async Task<IActionResult> Register([FromBody] RegisterDto dto)
        {
            try
            {
                var user = await _userService.RegisterAsync(dto);
                return Ok(ApiResponse<UserResponseDto>.SuccessResponse(user, ResponseMessages.RegisterSuccess));
            }
            catch (InvalidOperationException ex)
            {
                return BadRequest(ApiResponse<UserResponseDto>.ErrorResponse(ex.Message));
            }
            catch (Exception ex)
            {
                return StatusCode(500, ApiResponse<UserResponseDto>.ErrorResponse($"An error occurred: {ex.Message}"));
            }
        }
    }
}