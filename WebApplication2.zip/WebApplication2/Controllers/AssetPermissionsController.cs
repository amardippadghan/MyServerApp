using Microsoft.AspNetCore.Mvc;
using MyServerApp.Models;
using MyServerApp.Models.DTOs;
using MyServerApp.Services;

namespace MyServerApp.Controllers
{
    [ApiController]
    [Route("api/[controller]")]
    public class AssetPermissionsController : ControllerBase
    {
        private readonly IAssetPermissionService _permissionService;

        public AssetPermissionsController(IAssetPermissionService permissionService)
        {
            _permissionService = permissionService;
        }

        [HttpPost]
        public async Task<IActionResult> CreatePermission([FromBody] CreateAssetPermissionDto dto)
        {
            // TODO: Get current user from authentication
            int supervisorId = 1; // Replace with actual authenticated user ID
            UserType userType = UserType.Supervisor; // Replace with actual user type

            if (userType != UserType.Supervisor)
            {
                return Forbid();
            }

            var permission = await _permissionService.CreatePermissionAsync(dto, supervisorId);
            return Ok(permission);
        }

        [HttpPut("{permissionId}")]
        public async Task<IActionResult> UpdatePermission(int permissionId, [FromBody] UpdateAssetPermissionDto dto)
        {
            // TODO: Get current user from authentication
            int supervisorId = 1; // Replace with actual authenticated user ID
            UserType userType = UserType.Supervisor; // Replace with actual user type

            if (userType != UserType.Supervisor)
            {
                return Forbid();
            }

            var success = await _permissionService.UpdatePermissionAsync(permissionId, dto, supervisorId);
            if (!success)
            {
                return NotFound();
            }

            return Ok();
        }

        [HttpDelete("{permissionId}")]
        public async Task<IActionResult> DeletePermission(int permissionId)
        {
            // TODO: Get current user from authentication
            int supervisorId = 1; // Replace with actual authenticated user ID
            UserType userType = UserType.Supervisor; // Replace with actual user type

            if (userType != UserType.Supervisor)
            {
                return Forbid();
            }

            var success = await _permissionService.DeletePermissionAsync(permissionId, supervisorId);
            if (!success)
            {
                return NotFound();
            }

            return Ok();
        }

        [HttpGet("user/{userId}")]
        public async Task<IActionResult> GetUserPermissions(int userId)
        {
            // TODO: Get current user from authentication
            UserType userType = UserType.Supervisor; // Replace with actual user type

            if (userType != UserType.Supervisor)
            {
                return Forbid();
            }

            var permissions = await _permissionService.GetUserPermissionsAsync(userId);
            return Ok(permissions);
        }

        [HttpGet("asset/{assetId}/user/{userId}")]
        public async Task<IActionResult> GetPermission(int assetId, int userId)
        {
            var permission = await _permissionService.GetPermissionAsync(assetId, userId);
            if (permission == null)
            {
                return NotFound(new { message = $"Permission not found for asset {assetId} and user {userId}" });
            }

            return Ok(new
            {
                success = true,
                message = "Permission found",
                data = permission
            });
        }
    }
}