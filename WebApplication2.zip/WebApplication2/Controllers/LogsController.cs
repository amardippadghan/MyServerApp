﻿using Microsoft.AspNetCore.Mvc;
using MyServerApp.Models;
using MyServerApp.Models.DTOs;
using MyServerApp.Services;
using MySqlConnector;

namespace MyServerApp.Controllers
{
    [ApiController]
    [Route("api/[controller]")]
    public class LogsController : Controller
    {
        private readonly ILogsService _logs2Service;
        private readonly IConfiguration _configuration;

        public LogsController(ILogsService logs2Service, IConfiguration configuration)
        {
            _logs2Service = logs2Service;
            _configuration = configuration;
        }

        [HttpGet]
        public IActionResult GetAllLogs() =>
            Ok(_logs2Service.GetAllLogsAsync().Result);

        [HttpGet("{log_id}")]
        public IActionResult GetLogById(int log_id)
        {
            var log = _logs2Service.GetLogByIdAsync(log_id).Result;
            return log == null ? NotFound() : Ok(log);
        }

        [HttpPost]
        public IActionResult CreateLog([FromBody] CreateLogsDto dto)
        {
            if (dto == null) return BadRequest("Log data is null");
            var log = _logs2Service.CreateLogAsync(dto).Result;
            return Ok(new { message = "Log added successfully", log });
        }

        [HttpPut("{log_id}")]
        public IActionResult UpdateLog(int log_id, [FromBody] UpdateLogsDto dto)
        {
            if (!ModelState.IsValid) return BadRequest(ModelState);
            var updated = _logs2Service.UpdateLogAsync(log_id, dto).Result;
            return updated ? NoContent() : NotFound();
        }

        [HttpDelete("{log_id}")]
        public IActionResult DeleteLog(int log_id)
        {
            var deleted = _logs2Service.DeleteLogAsync(log_id).Result;
            return deleted ? NoContent() : NotFound();
        }

        [HttpGet("test-connection")]
        public IActionResult TestConnection()
        {
            try
            {
                using var conn = new MySqlConnection(_configuration.GetConnectionString("DefaultConnection"));
                conn.Open();
                return Ok(new { message = "Connection successful", timestamp = DateTime.UtcNow });
            }
            catch (Exception ex)
            {
                return StatusCode(500, new { error = ex.Message });
            }
        }
    }
}
