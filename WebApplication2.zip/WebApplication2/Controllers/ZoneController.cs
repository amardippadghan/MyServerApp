﻿using Microsoft.AspNetCore.Mvc;
using MyServerApp.Models;
using MyServerApp.Models.DTOs;
using MyServerApp.Services;
using MySqlConnector;

namespace MyServerApp.Controllers
{
    [ApiController]
    [Route("api/[controller]")]
    public class ZonesController : Controller
    {
        private readonly IZoneService _zoneService;
        private readonly IConfiguration _configuration;

        public ZonesController(IZoneService zoneService, IConfiguration configuration)
        {
            _zoneService = zoneService;
            _configuration = configuration;
        }

        [HttpGet]
        public IActionResult GetAllZones() =>
            Ok(_zoneService.GetAllZonesAsync().Result);

        [HttpGet("{id}")]
        public IActionResult GetZoneById(int id)
        {
            var zone = _zoneService.GetZoneByIdAsync(id).Result;
            return zone == null ? NotFound() : Ok(zone);
        }

        [HttpGet("type/{type}")]
        public IActionResult GetZonesByType(ZoneType type) =>
            Ok(_zoneService.GetZonesByTypeAsync(type).Result);

        [HttpPost]
        public IActionResult CreateZone([FromBody] CreateZoneDto dto)
        {
            if (dto == null) return BadRequest("Zone data is null");
            var zone = _zoneService.CreateZoneAsync(dto).Result;
            return Ok(new { message = "Zone added successfully", zone });
        }

        [HttpPut("{id}")]
        public IActionResult UpdateZone(int id, [FromBody] UpdateZoneDto dto)
        {
            if (!ModelState.IsValid) return BadRequest(ModelState);
            var updated = _zoneService.UpdateZoneAsync(id, dto).Result;
            return updated ? NoContent() : NotFound();
        }

        [HttpDelete("{id}")]
        public IActionResult DeleteZone(int id)
        {
            var deleted = _zoneService.DeleteZoneAsync(id).Result;
            return deleted ? NoContent() : NotFound();
        }

        [HttpGet("test-connection")]
        public IActionResult TestConnection()
        {
            try
            {
                using var conn = new MySqlConnection(_configuration.GetConnectionString("DefaultConnection"));
                conn.Open();
                return Ok(new { message = "Connection successful", timestamp = DateTime.UtcNow });
            }
            catch (Exception ex)
            {
                return StatusCode(500, new { error = ex.Message });
            }
        }
    }
}