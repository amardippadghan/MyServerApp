﻿using Microsoft.AspNetCore.Mvc;
using MyServerApp.Models.DTOs;
using MyServerApp.Services;
using MySqlConnector;

namespace MyServerApp.Controllers
{
    [ApiController]
    [Route("api/[controller]")]
    public class AlertsController : Controller
    {
        private readonly IAlertService _alertsService;
        private readonly IConfiguration _configuration;

        public AlertsController(IAlertService alertsService, IConfiguration configuration)
        {
            _alertsService = alertsService;
            _configuration = configuration;
        }

        [HttpGet]
        public IActionResult GetAllAlerts() =>
            Ok(_alertsService.GetAllAlertsAsync().Result);

        [HttpGet("{alertId}")]
        public IActionResult GetAlertById(int alertId)
        {
            var alert = _alertsService.GetAlertByIdAsync(alertId).Result;
            return alert == null ? NotFound() : Ok(alert);
        }

        [HttpPost]
        public IActionResult CreateAlert([FromBody] CreateAlertDto dto)
        {
            if (dto == null) return BadRequest("Alert data is null");
            var alert = _alertsService.CreateAlertAsync(dto).Result;
            return Ok(new { message = "Alert added successfully", alert });
        }

        [HttpPut("{alertId}")]
        public IActionResult UpdateAlert(int alertId, [FromBody] UpdateAlertDto dto)
        {
            if (!ModelState.IsValid) return BadRequest(ModelState);
            var updated = _alertsService.UpdateAlertAsync(alertId, dto).Result;
            return updated ? NoContent() : NotFound();
        }

        [HttpDelete("{alertId}")]
        public IActionResult DeleteAlert(int alertId)
        {
            var deleted = _alertsService.DeleteAlertAsync(alertId).Result;
            return deleted ? NoContent() : NotFound();
        }

        [HttpGet("test-connection")]
        public IActionResult TestConnection()
        {
            try
            {
                using var conn = new MySqlConnection(_configuration.GetConnectionString("DefaultConnection"));
                conn.Open();
                return Ok(new { message = "Connection successful", timestamp = DateTime.UtcNow });
            }
            catch (Exception ex)
            {
                return StatusCode(500, new { error = ex.Message });
            }
        }
    }
}
