using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using MyServerApp.Models;
using MyServerApp.Models.DTOs;
using MyServerApp.Services;
using System.Security.Claims;

namespace MyServerApp.Controllers
{
    [ApiController]
    [Authorize]
    [Route("api/[controller]")]
    public class AssetsController : ControllerBase
    {
        private readonly IAssetService _assetService;
        private readonly ILogger<AssetsController> _logger;

        public AssetsController(IAssetService assetService, ILogger<AssetsController> logger)
        {
            _assetService = assetService;
            _logger = logger;
        }

        private (int userId, UserType userType) GetUserInfo()
        {
            try
            {
                var userIdClaim = User.FindFirst(ClaimTypes.NameIdentifier)?.Value;
                var userTypeClaim = User.FindFirst(ClaimTypes.Role)?.Value;

                _logger.LogInformation($"Processing user claims - ID: {userIdClaim}, Role: {userTypeClaim}");

                if (string.IsNullOrEmpty(userIdClaim))
                {
                    throw new UnauthorizedAccessException("User ID not found in token");
                }

                if (string.IsNullOrEmpty(userTypeClaim))
                {
                    throw new UnauthorizedAccessException("User role not found in token");
                }

                var userType = userTypeClaim.Equals("Supervisor", StringComparison.OrdinalIgnoreCase)
                    ? UserType.Supervisor
                    : UserType.Worker;

                return (int.Parse(userIdClaim), userType);
            }
            catch (Exception ex)
            {
                _logger.LogError($"Error in GetUserInfo: {ex.Message}");
                throw new UnauthorizedAccessException($"Error processing user information: {ex.Message}");
            }
        }

        [HttpGet]
        public async Task<IActionResult> GetAllAssets()
        {
            try
            {
                _logger.LogInformation("GetAllAssets endpoint called");

                if (!User.Identity?.IsAuthenticated ?? true)
                {
                    _logger.LogWarning("Unauthorized access attempt - user not authenticated");
                    return Unauthorized(new { message = "User is not authenticated" });
                }

                var (userId, userType) = GetUserInfo();
                _logger.LogInformation($"Fetching assets for user {userId} with role {userType}");

                var assets = await _assetService.GetAllAssetsAsync(userId, userType);

                return Ok(new
                {
                    success = true,
                    message = "Assets retrieved successfully",
                    data = assets
                });
            }
            catch (UnauthorizedAccessException ex)
            {
                _logger.LogWarning($"Unauthorized access: {ex.Message}");
                return Unauthorized(new { message = ex.Message });
            }
            catch (Exception ex)
            {
                _logger.LogError($"Error in GetAllAssets: {ex.Message}");
                return StatusCode(500, new { message = "An error occurred while retrieving assets" });
            }
        }

        [HttpGet("{id}")]
        public async Task<IActionResult> GetAssetById(int id)
        {
            try
            {
                var (userId, userType) = GetUserInfo();
                var asset = await _assetService.GetAssetByIdAsync(id, userId, userType);

                if (asset == null)
                {
                    return NotFound(new { message = $"Asset with ID {id} not found" });
                }

                return Ok(new { success = true, data = asset });
            }
            catch (UnauthorizedAccessException ex)
            {
                return Unauthorized(new { message = ex.Message });
            }
        }

        [HttpPost]
        public async Task<IActionResult> CreateAsset([FromBody] CreateAssetDto dto)
        {
            try
            {
                var (userId, userType) = GetUserInfo();
                var asset = await _assetService.CreateAssetAsync(dto, userId, userType);
                return CreatedAtAction(nameof(GetAssetById), new { id = asset.AssetId }, new { success = true, data = asset });
            }
            catch (UnauthorizedAccessException ex)
            {
                return Unauthorized(new { message = ex.Message });
            }
        }

        [HttpPut("{id}")]
        public async Task<IActionResult> UpdateAsset(int id, [FromBody] UpdateAssetDto dto)
        {
            try
            {
                var (userId, userType) = GetUserInfo();
                var success = await _assetService.UpdateAssetAsync(id, dto, userId, userType);

                if (!success)
                {
                    return NotFound(new { message = $"Asset with ID {id} not found or you don't have permission to update it" });
                }

                return Ok(new { success = true, message = "Asset updated successfully" });
            }
            catch (UnauthorizedAccessException ex)
            {
                return Unauthorized(new { message = ex.Message });
            }
        }

        [HttpDelete("{id}")]
        public async Task<IActionResult> DeleteAsset(int id)
        {
            try
            {
                var (userId, userType) = GetUserInfo();
                var success = await _assetService.DeleteAssetAsync(id, userId, userType);

                if (!success)
                {
                    return NotFound(new { message = $"Asset with ID {id} not found or you don't have permission to delete it" });
                }

                return Ok(new { success = true, message = "Asset deleted successfully" });
            }
            catch (UnauthorizedAccessException ex)
            {
                return Unauthorized(new { message = ex.Message });
            }
        }
    }
}