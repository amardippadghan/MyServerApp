-- Update zones table to include zone type
ALTER TABLE zones1 
ADD COLUMN type TINYINT NOT NULL DEFAULT 0 
COMMENT '0: Unrestricted, 1: Restricted';