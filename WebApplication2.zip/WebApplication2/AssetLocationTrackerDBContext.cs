﻿using Microsoft.EntityFrameworkCore;
using MyServerApp.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AssetLocationTracker
{
    public class AssetLocationTrackerDBContext : DbContext
    {
        public AssetLocationTrackerDBContext(DbContextOptions<AssetLocationTrackerDBContext> options)
      : base(options)
        {
        }

        public DbSet<User> users { get; set; }
    }
}
