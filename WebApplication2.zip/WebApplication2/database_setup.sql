

-- Drop existing database and recreate
DROP DATABASE IF EXISTS asset_tracking;
CREATE DATABASE asset_tracking;
USE asset_tracking;

-- Drop any existing tables (in case they exist)
DROP TABLE IF EXISTS logs;
DROP TABLE IF EXISTS alerts;
DROP TABLE IF EXISTS asset_permissions;
DROP TABLE IF EXISTS assets;
DROP TABLE IF EXISTS zones;
DROP TABLE IF EXISTS users;

-- Create Users table
CREATE TABLE users (
    id INT PRIMARY KEY AUTO_INCREMENT,
    name VARCHAR(255) NOT NULL,
    email VARCHAR(255) NOT NULL UNIQUE,
    phone VARCHAR(20) NOT NULL,
    password VARCHAR(255) NOT NULL,
    type TINYINT NOT NULL DEFAULT 0, -- 0: Worker, 1: Supervisor
    created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    updated_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
);

-- Create Zones table
CREATE TABLE zones (
    zone_id INT PRIMARY KEY AUTO_INCREMENT,
    zone_name VARCHAR(255) NOT NULL,
    type TINYINT NOT NULL DEFAULT 0, -- 0: Unrestricted, 1: Restricted
    created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    updated_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
);

-- Create Assets table
CREATE TABLE assets (
    asset_id INT PRIMARY KEY AUTO_INCREMENT,
    asset_name VARCHAR(255) NOT NULL,
    description TEXT,
    type VARCHAR(100),
    zone_id INT NOT NULL,
    created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    updated_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    FOREIGN KEY (zone_id) REFERENCES zones(zone_id) ON DELETE RESTRICT
);

-- Create Alerts table
CREATE TABLE alerts (
    alert_id INT PRIMARY KEY AUTO_INCREMENT,
    asset_id INT NOT NULL,
    zone_id INT NOT NULL,
    alert_message TEXT NOT NULL,
    severity TINYINT NOT NULL DEFAULT 0, -- 0: Low, 1: Medium, 2: High
    status TINYINT NOT NULL DEFAULT 0, -- 0: New, 1: Acknowledged, 2: Resolved
    created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    updated_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    FOREIGN KEY (asset_id) REFERENCES assets(asset_id) ON DELETE CASCADE,
    FOREIGN KEY (zone_id) REFERENCES zones(zone_id) ON DELETE CASCADE
);

-- Create Logs table
CREATE TABLE logs (
    log_id INT PRIMARY KEY AUTO_INCREMENT,
    asset_id INT NOT NULL,
    user_id INT NOT NULL,
    zone_id INT NOT NULL,
    action VARCHAR(50) NOT NULL, -- e.g., 'MOVE', 'UPDATE', 'CREATE', 'DELETE'
    details TEXT,
    created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (asset_id) REFERENCES assets(asset_id) ON DELETE CASCADE,
    FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE,
    FOREIGN KEY (zone_id) REFERENCES zones(zone_id) ON DELETE CASCADE
);

-- Create Asset Permissions table
CREATE TABLE asset_permissions (
    permission_id INT PRIMARY KEY AUTO_INCREMENT,
    asset_id INT NOT NULL,
    user_id INT NOT NULL,
    can_view BOOLEAN DEFAULT true,
    can_update BOOLEAN DEFAULT false,
    can_delete BOOLEAN DEFAULT false,
    created_by INT NOT NULL,
    created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    updated_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    FOREIGN KEY (asset_id) REFERENCES assets(asset_id) ON DELETE CASCADE,
    FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE,
    FOREIGN KEY (created_by) REFERENCES users(id),
    UNIQUE KEY unique_asset_user (asset_id, user_id)
);

-- Add indexes for better query performance
CREATE INDEX idx_users_email ON users(email);
CREATE INDEX idx_assets_zone ON assets(zone_id);
CREATE INDEX idx_permissions_asset ON asset_permissions(asset_id);
CREATE INDEX idx_permissions_user ON asset_permissions(user_id);
CREATE INDEX idx_alerts_asset ON alerts(asset_id);
CREATE INDEX idx_alerts_zone ON alerts(zone_id);
CREATE INDEX idx_logs_asset ON logs(asset_id);
CREATE INDEX idx_logs_user ON logs(user_id);
CREATE INDEX idx_logs_zone ON logs(zone_id);
CREATE INDEX idx_logs_created_at ON logs(created_at);

-- Insert sample supervisor user with hashed password
INSERT INTO users (name, email, phone, password, type) VALUES
('Admin', 'admin@example.com', '1234567890', '$2a$11$CY9QngdqHq47F2CaPc7TYutqBcKM1DSw6vSMToZ5kw7Cp7jkG8v2G', 1); -- password: admin123

-- Insert sample zones
INSERT INTO zones (zone_name, type) VALUES
('Reception', 0),
('Office Area', 0),
('Server Room', 1),
('Storage', 1);

-- Insert sample assets
INSERT INTO assets (asset_name, description, type, zone_id) VALUES
('Laptop Dell XPS', 'Development laptop with 16GB RAM', 'Electronics', 2),
('Server Rack A', 'Main application server', 'Infrastructure', 3),
('Office Chair', 'Ergonomic office chair', 'Furniture', 2);

-- Insert sample asset permissions (for admin user)
INSERT INTO asset_permissions (asset_id, user_id, can_view, can_update, can_delete, created_by) VALUES
(1, 1, true, true, true, 1),
(2, 1, true, true, true, 1),
(3, 1, true, true, true, 1);

-- Insert sample alerts
INSERT INTO alerts (asset_id, zone_id, alert_message, severity, status) VALUES
(2, 3, 'High temperature detected in server rack', 2, 0);

-- Insert sample logs
INSERT INTO logs (asset_id, user_id, zone_id, action, details) VALUES
(1, 1, 2, 'CREATE', 'Asset created and assigned to Office Area'),
(2, 1, 3, 'CREATE', 'Asset created and assigned to Server Room');